import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Swal from 'sweetalert2';  // Import SweetAlert2
import { useForm, Controller } from 'react-hook-form';
import {
  createJob,
  getAllJobs,
  updateJob,
  deleteJob,
} from '../components/Services/jobService'; // Import service functions

const JobService2 = () => {
  const { control, handleSubmit, formState: { errors }, setValue } = useForm();
  
  const [rowData, setRowData] = useState([]);

  // Fetch all jobs from the API when the component mounts
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const jobs = await getAllJobs();
        setRowData(jobs);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      }
    };
    fetchJobs();
  }, []);

  // Handle form submission (Create or Update)
  const onSubmit = async (data) => {
    try {
      let job;
      // Create a new job or update an existing one
      if (data.jobno) {
        job = await updateJob(data.jobno, data);
        Swal.fire({
          icon: 'success',
          title: 'Job Updated',
          text: 'The job has been successfully updated!',
        });
      } else {
        job = await createJob(data);
        Swal.fire({
          icon: 'success',
          title: 'Job Created',
          text: 'The job has been successfully created!',
        });
      }

      setRowData([...rowData, job]); // Update grid data with the new/updated job

      // Reset form
      Object.keys(data).forEach((field) => setValue(field, ''));
    } catch (error) {
      console.error('Error submitting form:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an issue while submitting the form.',
      });
    }
  };

  // Handle delete action
  const handleDelete = async (jobId) => {
    try {
      // Show confirmation alert
      const result = await Swal.fire({
        title: 'Are you sure?',
        text: 'You won’t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel',
      });

      if (result.isConfirmed) {
        await deleteJob(jobId);
        setRowData(rowData.filter((job) => job.jobno !== jobId)); // Remove the job from the grid

        Swal.fire({
          icon: 'success',
          title: 'Deleted',
          text: 'The job has been deleted.',
        });
      }
    } catch (error) {
      console.error('Error deleting job:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an issue while deleting the job.',
      });
    }
  };

  // Define columns for AG-Grid
  const columns = [
    { headerName: 'Job No', field: 'jobno' },
    { headerName: 'Title', field: 'title' },
    { headerName: 'Project', field: 'project' },
    { headerName: 'Type', field: 'type' },
    { headerName: 'Date', field: 'date' },
    { headerName: 'PDC', field: 'pdc' },
    { headerName: 'Plan PDC', field: 'planpdc' },
    { headerName: 'Verification', field: 'verification' },
    { headerName: 'Job Status', field: 'jobstatus' },
    { headerName: 'Job Category', field: 'jobCategory' },
    { headerName: 'Mode of Usage', field: 'modeofusage' },
    { headerName: 'Process Planner', field: 'processplanner' },
    { headerName: 'Co-process Planner', field: 'coprocessplanner' },
    { headerName: 'Tool Design Planner', field: 'tooldesignplanner' },
    { headerName: 'Documentation Supervisor', field: 'documentationsupervisor' },
    { headerName: 'Production Coordinator', field: 'productioncoordinator' },
    { headerName: 'Mutual Agreed PDC', field: 'mutualagreedpdc' },
    { headerName: 'Percent of Accept', field: 'percentofaccept' },
    { headerName: 'Closing Date', field: 'closingdate' },
    { headerName: 'Work Order No', field: 'workorderno' },
    { headerName: 'Indenter Name', field: 'indentername' },
    { headerName: 'Indent Date', field: 'indtwodate' },
    { headerName: 'Indenter Division', field: 'indenterdiv' },
    { headerName: 'Telephone', field: 'tel' },
    {
      headerName: 'Actions', field: 'actions', cellRendererFramework: (params) => (
        <Button variant="danger" onClick={() => handleDelete(params.data.jobno)}>
          Delete
        </Button>
      )
    },
  ];

  return (
    <Container>
      <h2>Job Form</h2>
      <Form onSubmit={handleSubmit(onSubmit)}>
        {/* Row 1 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="jobno">
              <Form.Label>Job No</Form.Label>
              <Controller
                name="jobno"
                control={control}
                defaultValue=""
                rules={{ required: 'Job No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter job number"
                    isInvalid={!!errors.jobno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="title">
              <Form.Label>Title</Form.Label>
              <Controller
                name="title"
                control={control}
                defaultValue=""
                rules={{ required: 'Title is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter title"
                    isInvalid={!!errors.title}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.title?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="project">
              <Form.Label>Project</Form.Label>
              <Controller
                name="project"
                control={control}
                defaultValue=""
                rules={{ required: 'Project is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter project"
                    isInvalid={!!errors.project}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.project?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 2 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="type">
              <Form.Label>Type</Form.Label>
              <Controller
                name="type"
                control={control}
                defaultValue=""
                rules={{ required: 'Type is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter type"
                    isInvalid={!!errors.type}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.type?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="date">
              <Form.Label>Date</Form.Label>
              <Controller
                name="date"
                control={control}
                defaultValue=""
                rules={{ required: 'Date is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="date"
                    isInvalid={!!errors.date}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.date?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="pdc">
              <Form.Label>PDC</Form.Label>
              <Controller
                name="pdc"
                control={control}
                defaultValue=""
                rules={{ required: 'PDC is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter PDC"
                    isInvalid={!!errors.pdc}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.pdc?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 3 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="planpdc">
              <Form.Label>Plan PDC</Form.Label>
              <Controller
                name="planpdc"
                control={control}
                defaultValue=""
                rules={{ required: 'Plan PDC is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter plan PDC"
                    isInvalid={!!errors.planpdc}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.planpdc?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="verification">
              <Form.Label>Verification</Form.Label>
              <Controller
                name="verification"
                control={control}
                defaultValue=""
                rules={{ required: 'Verification is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter verification"
                    isInvalid={!!errors.verification}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.verification?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="jobstatus">
              <Form.Label>Job Status</Form.Label>
              <Controller
                name="jobstatus"
                control={control}
                defaultValue=""
                rules={{ required: 'Job Status is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter job status"
                    isInvalid={!!errors.jobstatus}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobstatus?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 4 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="jobCategory">
              <Form.Label>Job Category</Form.Label>
              <Controller
                name="jobCategory"
                control={control}
                defaultValue=""
                rules={{ required: 'Job Category is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter job category"
                    isInvalid={!!errors.jobCategory}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobCategory?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="modeofusage">
              <Form.Label>Mode of Usage</Form.Label>
              <Controller
                name="modeofusage"
                control={control}
                defaultValue=""
                rules={{ required: 'Mode of Usage is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter mode of usage"
                    isInvalid={!!errors.modeofusage}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.modeofusage?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="processplanner">
              <Form.Label>Process Planner</Form.Label>
              <Controller
                name="processplanner"
                control={control}
                defaultValue=""
                rules={{ required: 'Process Planner is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter process planner"
                    isInvalid={!!errors.processplanner}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.processplanner?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 5 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="coprocessplanner">
              <Form.Label>Co-process Planner</Form.Label>
              <Controller
                name="coprocessplanner"
                control={control}
                defaultValue=""
                rules={{ required: 'Co-process Planner is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter co-process planner"
                    isInvalid={!!errors.coprocessplanner}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.coprocessplanner?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="tooldesignplanner">
              <Form.Label>Tool Design Planner</Form.Label>
              <Controller
                name="tooldesignplanner"
                control={control}
                defaultValue=""
                rules={{ required: 'Tool Design Planner is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter tool design planner"
                    isInvalid={!!errors.tooldesignplanner}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.tooldesignplanner?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="documentationsupervisor">
              <Form.Label>Documentation Supervisor</Form.Label>
              <Controller
                name="documentationsupervisor"
                control={control}
                defaultValue=""
                rules={{ required: 'Documentation Supervisor is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter documentation supervisor"
                    isInvalid={!!errors.documentationsupervisor}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.documentationsupervisor?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 6 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="productioncoordinator">
              <Form.Label>Production Coordinator</Form.Label>
              <Controller
                name="productioncoordinator"
                control={control}
                defaultValue=""
                rules={{ required: 'Production Coordinator is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter production coordinator"
                    isInvalid={!!errors.productioncoordinator}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.productioncoordinator?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="mutualagreedpdc">
              <Form.Label>Mutual Agreed PDC</Form.Label>
              <Controller
                name="mutualagreedpdc"
                control={control}
                defaultValue=""
                rules={{ required: 'Mutual Agreed PDC is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter mutual agreed PDC"
                    isInvalid={!!errors.mutualagreedpdc}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.mutualagreedpdc?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="percentofaccept">
              <Form.Label>Percent of Accept</Form.Label>
              <Controller
                name="percentofaccept"
                control={control}
                defaultValue=""
                rules={{ required: 'Percent of Accept is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter percent of accept"
                    isInvalid={!!errors.percentofaccept}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.percentofaccept?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 7 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="closingdate">
              <Form.Label>Closing Date</Form.Label>
              <Controller
                name="closingdate"
                control={control}
                defaultValue=""
                rules={{ required: 'Closing Date is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="date"
                    isInvalid={!!errors.closingdate}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.closingdate?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="workorderno">
              <Form.Label>Work Order No</Form.Label>
              <Controller
                name="workorderno"
                control={control}
                defaultValue=""
                rules={{ required: 'Work Order No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter work order number"
                    isInvalid={!!errors.workorderno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.workorderno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="indentername">
              <Form.Label>Indenter Name</Form.Label>
              <Controller
                name="indentername"
                control={control}
                defaultValue=""
                rules={{ required: 'Indenter Name is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter indenter name"
                    isInvalid={!!errors.indentername}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.indentername?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Row 8 */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="indtwodate">
              <Form.Label>Indent Date</Form.Label>
              <Controller
                name="indtwodate"
                control={control}
                defaultValue=""
                rules={{ required: 'Indent Date is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="date"
                    isInvalid={!!errors.indtwodate}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.indtwodate?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="indenterdiv">
              <Form.Label>Indenter Division</Form.Label>
              <Controller
                name="indenterdiv"
                control={control}
                defaultValue=""
                rules={{ required: 'Indenter Division is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter indenter division"
                    isInvalid={!!errors.indenterdiv}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.indenterdiv?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="tel">
              <Form.Label>Telephone</Form.Label>
              <Controller
                name="tel"
                control={control}
                defaultValue=""
                rules={{ required: 'Telephone is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter telephone number"
                    isInvalid={!!errors.tel}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.tel?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            <Button variant="primary" type="submit">Submit</Button>
          </Col>
        </Row>
      </Form>

      {/* Display Jobs in AG Grid */}
      <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columns}
          domLayout="autoHeight"
        />
      </div>
    </Container>
  );
};

export default JobService2;
