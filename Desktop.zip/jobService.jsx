import axios from 'axios';

// Base URL for your API (adjust as needed)
const API_URL = 'https://your-api-url.com/jobs';

// Create a job
export const createJob = async (jobData) => {
  try {
    const response = await axios.post(API_URL, jobData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Get all jobs
export const getAllJobs = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Update a job
export const updateJob = async (jobId, jobData) => {
  try {
    const response = await axios.put(`${API_URL}/${jobId}`, jobData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Delete a job
export const deleteJob = async (jobId) => {
  try {
    const response = await axios.delete(`${API_URL}/${jobId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};
