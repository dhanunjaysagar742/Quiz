import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Swal from 'sweetalert2';
import { useForm, Controller } from 'react-hook-form';
import {
  createJob,
  getAllJobs,
  updateJob,
  deleteJob,
} from './jobService'; // Import service functions

const JobForm = () => {
  const { control, handleSubmit, formState: { errors }, setValue } = useForm();
  const [rowData, setRowData] = useState([]);
  
  // Fetch all jobs when the component mounts
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const jobs = await getAllJobs();
        setRowData(jobs);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      }
    };
    fetchJobs();
  }, []);

  // Handle form submission (Create or Update)
  const onSubmit = async (data) => {
    try {
      let job;
      // If jobno exists, update the job, else create a new job
      if (data.jobno) {
        job = await updateJob(data.jobno, data);
        Swal.fire({
          icon: 'success',
          title: 'Job Updated',
          text: 'The job has been successfully updated!',
        });
      } else {
        job = await createJob(data);
        Swal.fire({
          icon: 'success',
          title: 'Job Created',
          text: 'The job has been successfully created!',
        });
      }

      setRowData([...rowData, job]); // Update grid data with new job

      // Reset form after submission
      Object.keys(data).forEach((field) => setValue(field, ''));
    } catch (error) {
      console.error('Error submitting form:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an issue while submitting the form.',
      });
    }
  };

  // Handle delete action
  const handleDelete = async (jobId) => {
    try {
      // Show confirmation alert
      const result = await Swal.fire({
        title: 'Are you sure?',
        text: 'You won’t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel',
      });

      if (result.isConfirmed) {
        await deleteJob(jobId);
        setRowData(rowData.filter((job) => job.jobno !== jobId)); // Remove the job from the grid

        Swal.fire({
          icon: 'success',
          title: 'Deleted',
          text: 'The job has been deleted.',
        });
      }
    } catch (error) {
      console.error('Error deleting job:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an issue while deleting the job.',
      });
    }
  };

  // Define columns for AG-Grid
  const columns = [
    { headerName: 'Job No', field: 'jobno' },
    { headerName: 'Title', field: 'title' },
    { headerName: 'Project', field: 'project' },
    { headerName: 'Type', field: 'type' },
    { headerName: 'Date', field: 'date' },
    { headerName: 'PDC', field: 'pdc' },
    { headerName: 'Plan PDC', field: 'planpdc' },
    { headerName: 'Verification', field: 'verification' },
    { headerName: 'Job Status', field: 'jobstatus' },
    { headerName: 'Job Category', field: 'jobCategory' },
    { headerName: 'Mode of Usage', field: 'modeofusage' },
    { headerName: 'Process Planner', field: 'processplanner' },
    { headerName: 'Co-process Planner', field: 'coprocessplanner' },
    { headerName: 'Tool Design Planner', field: 'tooldesignplanner' },
    { headerName: 'Documentation Supervisor', field: 'documentationsupervisor' },
    { headerName: 'Production Coordinator', field: 'productioncoordinator' },
    { headerName: 'Mutual Agreed PDC', field: 'mutualagreedpdc' },
    { headerName: 'Percent of Accept', field: 'percentofaccept' },
    { headerName: 'Closing Date', field: 'closingdate' },
    { headerName: 'Work Order No', field: 'workorderno' },
    { headerName: 'Indenter Name', field: 'indentername' },
    { headerName: 'Indent Date', field: 'indtwodate' },
    { headerName: 'Indenter Division', field: 'indenterdiv' },
    { headerName: 'Telephone', field: 'tel' },
    {
      headerName: 'Actions', field: 'actions', cellRendererFramework: (params) => (
        <Button variant="danger" onClick={() => handleDelete(params.data.jobno)}>
          Delete
        </Button>
      )
    },
  ];

  return (
    <Container>
      <h2>Job Form</h2>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col md={4}>
            <Form.Group controlId="jobno">
              <Form.Label>Job No</Form.Label>
              <Controller
                name="jobno"
                control={control}
                defaultValue=""
                rules={{ required: 'Job No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter job number"
                    isInvalid={!!errors.jobno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="title">
              <Form.Label>Title</Form.Label>
              <Controller
                name="title"
                control={control}
                defaultValue=""
                rules={{ required: 'Title is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter title"
                    isInvalid={!!errors.title}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.title?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="project">
              <Form.Label>Project</Form.Label>
              <Controller
                name="project"
                control={control}
                defaultValue=""
                rules={{ required: 'Project is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter project"
                    isInvalid={!!errors.project}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.project?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col md={4}>
            <Form.Group controlId="type">
              <Form.Label>Type</Form.Label>
              <Controller
                name="type"
                control={control}
                defaultValue=""
                rules={{ required: 'Type is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter type"
                    isInvalid={!!errors.type}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.type?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="date">
              <Form.Label>Date</Form.Label>
              <Controller
                name="date"
                control={control}
                defaultValue=""
                rules={{ required: 'Date is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="date"
                    isInvalid={!!errors.date}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.date?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="pdc">
              <Form.Label>PDC</Form.Label>
              <Controller
                name="pdc"
                control={control}
                defaultValue=""
                rules={{ required: 'PDC is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter PDC"
                    isInvalid={!!errors.pdc}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.pdc?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col md={4}>
            <Form.Group controlId="planpdc">
              <Form.Label>Plan PDC</Form.Label>
              <Controller
                name="planpdc"
                control={control}
                defaultValue=""
                rules={{ required: 'Plan PDC is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Plan PDC"
                    isInvalid={!!errors.planpdc}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.planpdc?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="verification">
              <Form.Label>Verification</Form.Label>
              <Controller
                name="verification"
                control={control}
                defaultValue=""
                rules={{ required: 'Verification is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Verification"
                    isInvalid={!!errors.verification}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.verification?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="jobstatus">
              <Form.Label>Job Status</Form.Label>
              <Controller
                name="jobstatus"
                control={control}
                defaultValue=""
                rules={{ required: 'Job Status is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Job Status"
                    isInvalid={!!errors.jobstatus}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobstatus?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Repeat for other fields similarly */}
        
        {/* Submit button */}
        <Row>
          <Col>
            <Button variant="primary" type="submit">Submit</Button>
          </Col>
        </Row>
      </Form>

      {/* AG-Grid to display job records */}
      <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columns}
          domLayout="autoHeight"
        />
      </div>
    </Container>
  );
};

export default JobForm;
