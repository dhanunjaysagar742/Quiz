import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Swal from 'sweetalert2';
import { useForm, Controller } from 'react-hook-form';
import {
  createJob,
  getAllJobs,
  updateJob,
  deleteJob,
} from '../components/Services/jobService'; // Import service functions

const LotMaster = () => {
  const { control, handleSubmit, formState: { errors }, setValue } = useForm();
  const [rowData, setRowData] = useState([]);
  
  // Fetch all jobs when the component mounts
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const jobs = await getAllJobs();
        setRowData(jobs);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      }
    };
    fetchJobs();
  }, []);

  // Handle form submission (Create or Update)
  const onSubmit = async (data) => {
    try {
      let job;
      // If jobno exists, update the job, else create a new job
      if (data.jobno) {
        job = await updateJob(data.jobno, data);
        Swal.fire({
          icon: 'success',
          title: 'Job Updated',
          text: 'The job has been successfully updated!',
        });
      } else {
        job = await createJob(data);
        Swal.fire({
          icon: 'success',
          title: 'Job Created',
          text: 'The job has been successfully created!',
        });
      }

      setRowData([...rowData, job]); // Update grid data with new job

      // Reset form after submission
      Object.keys(data).forEach((field) => setValue(field, ''));
    } catch (error) {
      console.error('Error submitting form:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an issue while submitting the form.',
      });
    }
  };

  // Handle delete action
  const handleDelete = async (jobId) => {
    try {
      // Show confirmation alert
      const result = await Swal.fire({
        title: 'Are you sure?',
        text: 'You won’t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel',
      });

      if (result.isConfirmed) {
        await deleteJob(jobId);
        setRowData(rowData.filter((job) => job.jobno !== jobId)); // Remove the job from the grid

        Swal.fire({
          icon: 'success',
          title: 'Deleted',
          text: 'The job has been deleted.',
        });
      }
    } catch (error) {
      console.error('Error deleting job:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an issue while deleting the job.',
      });
    }
  };

  // Define columns for AG-Grid
  const columns = [
    { headerName: 'Sl No', field: 'slno' },
    { headerName: 'IR No', field: 'irno' },
    { headerName: 'Job Type', field: 'jobtype' },
    { headerName: 'Lot ID', field: 'lotid' },
    { headerName: 'OPN No', field: 'opnno' },
    { headerName: 'Project', field: 'project' },
    { headerName: 'Job No', field: 'jobno' },
    { headerName: 'Item No', field: 'itemno' },
    { headerName: 'Lot No', field: 'lotno' },
    { headerName: 'Item Nomenclature', field: 'itemnomenclature' },
    { headerName: 'IR Date', field: 'irdate' },
    { headerName: 'IR Initiator', field: 'irinitiator' },
    { headerName: 'IR Quality Status', field: 'irqualitystatus' },
    { headerName: 'IR Status', field: 'irstatus' },
    { headerName: 'Passed', field: 'passed' },
    { headerName: 'Accepted', field: 'accepted' },
    { headerName: 'Rejected', field: 'rejected' },
    { headerName: 'Rework', field: 'rework' },
    { headerName: 'Note', field: 'note' },
    { headerName: 'IR Quality Observation', field: 'irqualityobservation' },
    { headerName: 'Inspected', field: 'inspected' },
    { headerName: 'QC Work Centre', field: 'qcworkcentre' },
    { headerName: 'Inspectors', field: 'inspectors' },
    { headerName: 'Specification No', field: 'specificationno' },
    { headerName: 'Specification', field: 'specification' },
    { headerName: 'Specification Type', field: 'specificationtype' },
    { headerName: 'Specification Details', field: 'specificationdetails' },
    { headerName: 'DWG Loc', field: 'Dwgloc' },
    { headerName: 'IR Request Opt Desc', field: 'ireqoptdesc' },
    { headerName: 'Default Tolerance', field: 'defaulttolerance' },
    { headerName: 'Instrument No', field: 'instrumentno' },
    { headerName: 'Instrument Code', field: 'instrumentcode' },
    { headerName: 'Instrument ID', field: 'instrumentid' },
    {
      headerName: 'Actions', field: 'actions', cellRendererFramework: (params) => (
        <Button variant="danger" onClick={() => handleDelete(params.data.jobno)}>
          Delete
        </Button>
      )
    },
  ];

  return (
    <Container>
      <h2>Job Form</h2>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col md={4}>
            <Form.Group controlId="slno">
              <Form.Label>Sl No</Form.Label>
              <Controller
                name="slno"
                control={control}
                defaultValue=""
                rules={{ required: 'Sl No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Sl No"
                    isInvalid={!!errors.slno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.slno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
          
          <Col md={4}>
            <Form.Group controlId="irno">
              <Form.Label>IR No</Form.Label>
              <Controller
                name="irno"
                control={control}
                defaultValue=""
                rules={{ required: 'IR No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter IR No"
                    isInvalid={!!errors.irno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.irno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="jobtype">
              <Form.Label>Job Type</Form.Label>
              <Controller
                name="jobtype"
                control={control}
                defaultValue=""
                rules={{ required: 'Job Type is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Job Type"
                    isInvalid={!!errors.jobtype}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobtype?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col md={4}>
            <Form.Group controlId="lotid">
              <Form.Label>Lot ID</Form.Label>
              <Controller
                name="lotid"
                control={control}
                defaultValue=""
                rules={{ required: 'Lot ID is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Lot ID"
                    isInvalid={!!errors.lotid}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.lotid?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="opnno">
              <Form.Label>OPN No</Form.Label>
              <Controller
                name="opnno"
                control={control}
                defaultValue=""
                rules={{ required: 'OPN No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter OPN No"
                    isInvalid={!!errors.opnno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.opnno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="project">
              <Form.Label>Project</Form.Label>
              <Controller
                name="project"
                control={control}
                defaultValue=""
                rules={{ required: 'Project is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Project"
                    isInvalid={!!errors.project}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.project?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col md={4}>
            <Form.Group controlId="jobno">
              <Form.Label>Job No</Form.Label>
              <Controller
                name="jobno"
                control={control}
                defaultValue=""
                rules={{ required: 'Job No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Job No"
                    isInvalid={!!errors.jobno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.jobno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="itemno">
              <Form.Label>Item No</Form.Label>
              <Controller
                name="itemno"
                control={control}
                defaultValue=""
                rules={{ required: 'Item No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Item No"
                    isInvalid={!!errors.itemno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.itemno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="lotno">
              <Form.Label>Lot No</Form.Label>
              <Controller
                name="lotno"
                control={control}
                defaultValue=""
                rules={{ required: 'Lot No is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Lot No"
                    isInvalid={!!errors.lotno}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.lotno?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Add more rows for the other fields in the same way */}
        <Row>
          <Col md={4}>
            <Form.Group controlId="itemnomenclature">
              <Form.Label>Item Nomenclature</Form.Label>
              <Controller
                name="itemnomenclature"
                control={control}
                defaultValue=""
                rules={{ required: 'Item Nomenclature is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter Item Nomenclature"
                    isInvalid={!!errors.itemnomenclature}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.itemnomenclature?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="irdate">
              <Form.Label>IR Date</Form.Label>
              <Controller
                name="irdate"
                control={control}
                defaultValue=""
                rules={{ required: 'IR Date is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="date"
                    isInvalid={!!errors.irdate}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.irdate?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>

          <Col md={4}>
            <Form.Group controlId="irinitiator">
              <Form.Label>IR Initiator</Form.Label>
              <Controller
                name="irinitiator"
                control={control}
                defaultValue=""
                rules={{ required: 'IR Initiator is mandatory' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter IR Initiator"
                    isInvalid={!!errors.irinitiator}
                  />
                )}
              />
              <Form.Control.Feedback type="invalid">{errors.irinitiator?.message}</Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>

        {/* Continue adding fields for other properties in the same way */}
        
        <Row>
          <Col>
            <Button variant="primary" type="submit">Submit</Button>
          </Col>
        </Row>
      </Form>

      {/* AG-Grid to display job records */}
      <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columns}
          domLayout="autoHeight"
        />
      </div>
    </Container>
  );
};

export default LotMaster;
